<?php $icons = array();
$icons['stmicons']['advisory-quotes'] = array("class"=>'advisory-quotes',"tags"=>'quotes');
$icons['stmicons']['advisory-banking'] = array("class"=>'advisory-banking',"tags"=>'advisory,banking');
$icons['stmicons']['advisory-construction'] = array("class"=>'advisory-construction',"tags"=>'counstruction');
$icons['stmicons']['advisory-government'] = array("class"=>'advisory-government',"tags"=>'government');
$icons['stmicons']['advisory-not-for-profit'] = array("class"=>'advisory-not-for-profit',"tags"=>'not-for-profit');
$icons['stmicons']['advisory-food'] = array("class"=>'advisory-food',"tags"=>'food');
$icons['stmicons']['advisory-healthcare'] = array("class"=>'advisory-healthcare',"tags"=>'healthcare');