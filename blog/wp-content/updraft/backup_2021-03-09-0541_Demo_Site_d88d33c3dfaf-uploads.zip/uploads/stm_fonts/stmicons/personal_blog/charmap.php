<?php $icons = array();
$icons['stmicons']['blog_arrow_left'] = array("class"=>'blog_arrow_left',"tags"=>'blog_arrow_left');
$icons['stmicons']['blog_arrow_right'] = array("class"=>'blog_arrow_right',"tags"=>'blog_arrow_right');
$icons['stmicons']['blog_cart'] = array("class"=>'blog_cart',"tags"=>'blog_cart');
$icons['stmicons']['blog_divider'] = array("class"=>'blog_divider',"tags"=>'blog_divider');
$icons['stmicons']['blog_icon-quote'] = array("class"=>'blog_icon-quote',"tags"=>'blog_icon-quote');
$icons['stmicons']['blog_search'] = array("class"=>'blog_search',"tags"=>'blog_search');