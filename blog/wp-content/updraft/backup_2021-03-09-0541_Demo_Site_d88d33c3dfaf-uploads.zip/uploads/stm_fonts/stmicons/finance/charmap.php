<?php $icons = array();
$icons['stmicons']['banking'] = array("class"=>'banking',"tags"=>'banking');
$icons['stmicons']['estate'] = array("class"=>'estate',"tags"=>'estate');
$icons['stmicons']['food'] = array("class"=>'food',"tags"=>'food');
$icons['stmicons']['phone'] = array("class"=>'phone',"tags"=>'phone');