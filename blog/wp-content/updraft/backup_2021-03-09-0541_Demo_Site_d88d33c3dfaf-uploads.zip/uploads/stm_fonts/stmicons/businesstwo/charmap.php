<?php $icons = array();
$icons['stmicons']['businesstwo_aircraft'] = array("class"=>'businesstwo_aircraft',"tags"=>'businesstwo_aircraft');
$icons['stmicons']['businesstwo_heart'] = array("class"=>'businesstwo_heart',"tags"=>'businesstwo_heart');
$icons['stmicons']['businesstwo_like'] = array("class"=>'businesstwo_like',"tags"=>'businesstwo_like');
$icons['stmicons']['businesstwo_schedule'] = array("class"=>'businesstwo_schedule',"tags"=>'businesstwo_schedule');