<?php $icons = array();
$icons['stmicons']['logisticstwo-truck'] = array("class"=>'logisticstwo-truck',"tags"=>'logisticstwo-truck');
$icons['stmicons']['logisticstwo-air-freight'] = array("class"=>'logisticstwo-air-freight',"tags"=>'logisticstwo-air-freight');
$icons['stmicons']['logisticstwo-box'] = array("class"=>'logisticstwo-box',"tags"=>'logisticstwo-box');
$icons['stmicons']['logisticstwo-briefcase'] = array("class"=>'logisticstwo-briefcase',"tags"=>'logisticstwo-briefcase');
$icons['stmicons']['logisticstwo-clipboards'] = array("class"=>'logisticstwo-clipboards',"tags"=>'logisticstwo-clipboards');
$icons['stmicons']['logisticstwo-list'] = array("class"=>'logisticstwo-list',"tags"=>'logisticstwo-list');
$icons['stmicons']['logisticstwo-ship'] = array("class"=>'logisticstwo-ship',"tags"=>'logisticstwo-ship');
$icons['stmicons']['logisticstwo-team'] = array("class"=>'logisticstwo-team',"tags"=>'logisticstwo-team');
