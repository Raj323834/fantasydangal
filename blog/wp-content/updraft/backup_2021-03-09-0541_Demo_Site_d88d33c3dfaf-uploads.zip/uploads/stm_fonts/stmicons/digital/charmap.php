<?php $icons = array();
$icons['stmicons']['digital_diamond'] = array("class"=>'digital_diamond',"tags"=>'pearl_digital_diamond');
$icons['stmicons']['digital_monitor'] = array("class"=>'digital_monitor',"tags"=>'pearl_digital_monitor');
$icons['stmicons']['digital_quote'] = array("class"=>'digital_quote',"tags"=>'pearl_digital_quote');
$icons['stmicons']['digital_reload'] = array("class"=>'digital_reload',"tags"=>'pearl_digital_reload');