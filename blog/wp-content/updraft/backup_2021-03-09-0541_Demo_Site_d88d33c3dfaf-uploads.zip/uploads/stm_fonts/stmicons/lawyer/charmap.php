<?php $icons = array();
$icons['stmicons']['lawyer_envelope'] = array("class"=>'lawyer_envelope',"tags"=>'envelope');
$icons['stmicons']['lawyer_iphone'] = array("class"=>'lawyer_iphone',"tags"=>'iphone');
$icons['stmicons']['lawyer_pin'] = array("class"=>'lawyer_pin',"tags"=>'pin');
$icons['stmicons']['lawyer_printer'] = array("class"=>'lawyer_printer',"tags"=>'printer');
$icons['stmicons']['lawyer_arrow'] = array("class"=>'lawyer_arrow',"tags"=>'lawyer_arrow');