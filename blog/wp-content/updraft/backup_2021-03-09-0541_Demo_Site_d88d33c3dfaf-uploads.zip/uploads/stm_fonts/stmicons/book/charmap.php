<?php $icons = array();
$icons['stmicons']['coin-stack'] = array("class"=>'coin-stack',"tags"=>'coin-stack');
$icons['stmicons']['like'] = array("class"=>'like',"tags"=>'like');
$icons['stmicons']['medal'] = array("class"=>'medal',"tags"=>'medal');
$icons['stmicons']['shopping-bag'] = array("class"=>'shopping-bag',"tags"=>'shopping-bag');
$icons['stmicons']['waiter'] = array("class"=>'waiter',"tags"=>'waiter');