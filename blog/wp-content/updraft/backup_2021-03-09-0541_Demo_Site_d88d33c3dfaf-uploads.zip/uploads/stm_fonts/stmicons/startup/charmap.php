<?php $icons = array();
$icons['stmicons']['mountain_flag'] = array("class"=>'mountain_flag',"tags"=>'mountain_flag');
$icons['stmicons']['pigtime'] = array("class"=>'pigtime',"tags"=>'pigtime');
$icons['stmicons']['startup_back'] = array("class"=>'startup_back',"tags"=>'startup_back');
$icons['stmicons']['startup_crown'] = array("class"=>'startup_crown',"tags"=>'startup_crown');
$icons['stmicons']['zzz'] = array("class"=>'zzz',"tags"=>'zzz');