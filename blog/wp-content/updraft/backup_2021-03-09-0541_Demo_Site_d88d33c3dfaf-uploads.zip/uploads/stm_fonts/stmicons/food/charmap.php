<?php $icons = array();
$icons['stmicons']['coffee'] = array("class"=>'coffee',"tags"=>'coffee');
$icons['stmicons']['award'] = array("class"=>'award',"tags"=>'award');
$icons['stmicons']['group2'] = array("class"=>'group2',"tags"=>'group');
$icons['stmicons']['telephone'] = array("class"=>'telephone',"tags"=>'telephone');
$icons['stmicons']['shopping-bag'] = array("class"=>'shopping-bag',"tags"=>'shopping-bag');