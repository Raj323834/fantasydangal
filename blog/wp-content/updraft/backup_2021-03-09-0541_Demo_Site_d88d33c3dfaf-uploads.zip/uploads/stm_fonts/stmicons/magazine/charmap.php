<?php $icons = array();
$icons['stmicons']['magazine-user'] = array("class"=>'magazine-user',"tags"=>'magazine-user');
$icons['stmicons']['magazine-calendar'] = array("class"=>'magazine-calendar',"tags"=>'magazine-calendar');
$icons['stmicons']['magazine-comment'] = array("class"=>'magazine-comment',"tags"=>'magazine-comment');
$icons['stmicons']['magazine-quote'] = array("class"=>'magazine-quote',"tags"=>'magazine-quote');
$icons['stmicons']['magazine-search'] = array("class"=>'magazine-search',"tags"=>'magazine-search');
$icons['stmicons']['magazine-tag'] = array("class"=>'magazine-tag',"tags"=>'magazine-tag');
$icons['stmicons']['magazine-view'] = array("class"=>'magazine-view',"tags"=>'magazine-view');