export const appRun = ($window) => {
    "use strict";


};