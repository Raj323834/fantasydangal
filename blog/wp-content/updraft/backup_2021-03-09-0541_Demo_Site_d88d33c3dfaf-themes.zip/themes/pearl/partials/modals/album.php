<?php if (pearl_check_music_enabled()) {
    wp_enqueue_script('pearl_modal/album');
}