<?php if(pearl_check_string(pearl_get_option('scroll_top_button', 'false'))): ?>
    <div class="pearl_arrow_top">
        <div class="arrow"></div>
    </div>
<?php endif;