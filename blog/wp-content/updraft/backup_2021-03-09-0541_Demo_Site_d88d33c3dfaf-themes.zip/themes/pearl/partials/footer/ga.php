<?php if (function_exists('stm_get_ga_code')) {
	stm_get_ga_code();
}