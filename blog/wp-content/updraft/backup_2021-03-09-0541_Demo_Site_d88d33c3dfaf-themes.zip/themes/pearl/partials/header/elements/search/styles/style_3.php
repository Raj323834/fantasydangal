<a href="#" data-toggle="modal" data-target="#searchModal" class="mbdc wtc_h hidden-sm hidden-xs">
    <i class="stm-search__icon stm-search__icon_rounded icon_14px  fa fa-search"></i>
</a>
<div class="hidden-lg hidden-md stm_widget_search">
    <div class="widget widget_search">
        <?php get_search_form(); ?>
    </div>
</div>