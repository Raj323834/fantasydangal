<?php $css = (!empty($css)) ? $css : ''; ?>
<div class="stm_separator_wrapper stm_separator_<?php echo esc_attr($style); ?> <?php echo esc_attr($css); ?>">
	<div class="<?php echo esc_attr(implode(' ', $classes)); ?>"
		 style="<?php echo esc_attr(implode(';', array_filter($styles))); ?>"></div>
</div>